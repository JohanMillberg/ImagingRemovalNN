#!/bin/bash

module load python3/3.9.5
module load python_ML_packages/3.9.5-gpu

pip install scipy
pip install cupy-cuda111
